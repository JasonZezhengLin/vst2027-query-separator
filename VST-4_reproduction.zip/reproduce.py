from pathlib import Path
import collections,json,sys
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'code'))
from score import score,decode,proto
requests=json.loads((R/'data/conditions.json').read_text());saved=json.loads((R/'results/vst4_disclosure_scores/snapshot.json').read_text());by={x['id']:x for x in saved['scores']};out=[]
for q in requests:
 v=json.loads((R/'results/model_raw'/(q['id']+'.json')).read_text());a=score(v['text'],q['task_ids'])
 for k,x in a.items():assert by[q['id']][k]==x,(q['id'],k)
 out.append({**a,'id':q['id'],'model':q['model'],'unit':q['unit'],'seed':q['seed'],'diff_disclosed':q['diff_disclosed'],'execution_disclosed':q['execution_disclosed']})
ids=[r['id'] for r in proto['records']];gold={r['id']:({'value':repr(decode(r['new_expected']['value']))} if 'value' in r['new_expected'] else r['new_expected']) for r in proto['records'] if r['obligation']=='revised'}
controls={'noop':score('{"drop":[],"replace":{}}',ids),'delete_all':score(json.dumps({'drop':ids,'replace':{}}),ids),'contract_complete':score(json.dumps({'drop':[],'replace':gold}),ids)}
assert len(out)==72 and sum(x['after_correct_pass'] for x in out)==0 and len(controls['contract_complete']['detected_faults'])==8
O=R/'reproduced';O.mkdir(exist_ok=False);(O/'scores.json').write_text(json.dumps(out,indent=2)+'\n');(O/'controls.json').write_text(json.dumps(controls,indent=2)+'\n');print(json.dumps({'result':'PASS','responses_rescored':len(out),'reference_valid_suites':0,'contract_control_detected_faults':8}),flush=True)
