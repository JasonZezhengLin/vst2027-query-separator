"""Score inert literal-data repair edits on archived native outcomes; no generated code execution."""
from pathlib import Path
import json, ast, hashlib, datetime, collections
R = Path(__file__).resolve().parents[1]

def decode(x):
    t = x['type']
    if t == 'bytes':
        return bytes.fromhex(x['hex'])
    if t in ['str', 'bool', 'int']:
        return x['value']
    if t == 'null':
        return None
    if t == 'list':
        return [decode(y) for y in x['items']]
    if t == 'tuple':
        return tuple((decode(y) for y in x['items']))
    if t == 'dict':
        return {decode(k): decode(v) for k, v in x['items']}
    raise ValueError(t)

def equal(a, b):
    if type(a) is not type(b):
        return False
    if isinstance(a, (list, tuple)):
        return len(a) == len(b) and all((equal(x, y) for x, y in zip(a, b)))
    if isinstance(a, dict):
        return a.keys() == b.keys() and all((equal(a[k], b[k]) for k in a))
    return a == b

def literal(text):
    if not isinstance(text, str) or len(text) > 8192:
        raise ValueError('literal length/type')
    tree = ast.parse(text, mode='eval')
    nodes = list(ast.walk(tree))
    assert len(nodes) <= 4096, 'literal node cap'
    allowed = (ast.Expression, ast.Constant, ast.List, ast.Tuple, ast.Dict, ast.Set, ast.Load, ast.UnaryOp, ast.UAdd, ast.USub)
    if any((not isinstance(n, allowed) for n in nodes)):
        raise ValueError('nonliteral AST')

    def depth(n):
        return 1 + max((depth(y) for y in ast.iter_child_nodes(n)), default=0)
    if depth(tree) > 40:
        raise ValueError('literal depth')
    return ast.literal_eval(tree)

def no_duplicates(pairs):
    out = {}
    for k, v in pairs:
        if k in out:
            raise ValueError('duplicate JSON key')
        out[k] = v
    return out

def parse(text, ids):
    if not isinstance(text, str) or len(text) > 65536:
        raise ValueError('response length/type')
    j = json.loads(text, object_pairs_hook=no_duplicates, parse_constant=lambda x: (_ for _ in ()).throw(ValueError('nonfinite JSON')))
    if not isinstance(j, dict) or set(j) != {'drop', 'replace'} or (not isinstance(j['drop'], list)) or (not isinstance(j['replace'], dict)):
        raise ValueError('edit schema')
    if any((not isinstance(x, str) for x in j['drop'])) or len(j['drop']) != len(set(j['drop'])):
        raise ValueError('drop IDs')
    if not (set(j['drop']) | set(j['replace'])).issubset(ids) or set(j['drop']) & set(j['replace']):
        raise ValueError('unknown or conflicting IDs')
    rep = {}
    for k, e in j['replace'].items():
        if not isinstance(e, dict) or len(e) != 1:
            raise ValueError('expectation schema')
        if set(e) == {'value'}:
            rep[k] = {'data_value': literal(e['value'])}
        elif set(e) == {'exception'} and isinstance(e['exception'], str):
            rep[k] = e
        elif set(e) == {'no_exception'} and e['no_exception'] is True:
            rep[k] = e
        else:
            raise ValueError('unsupported expectation')
    return (set(j['drop']), rep)

def expected(e):
    return {'data_value': decode(e['value'])} if 'value' in e else e

def matches(got, e):
    if 'exception' in e:
        return got.get('exception') == e['exception']
    if e.get('no_exception'):
        return 'exception' not in got
    return 'value' in got and equal(decode(got['value']), e['data_value'])
proto = json.loads((R / 'protocol/vst4_query_separator_development_v2.json').read_text())
raw = json.loads((R / 'results/vst4_query_separator_development_v2/native_execution.json').read_text())
runs = {(x['variant'], x['id']): x for x in raw['result']['records']}
faults = [x['name'] for x in proto['mutations']]
allbyid = {x['id']: x for x in proto['records']}
native_summary = json.loads((R / 'results/vst4_query_separator_development_v2/summary.json').read_text())
gold_control = next((x for x in native_summary['suite_controls'] if x['control'] == 'contract_complete_update'))
retained_faults = set(gold_control['detected_admitted_retained_faults'])
changed_faults = set(gold_control['detected_changed_contract_faults'])
assert retained_faults.isdisjoint(changed_faults) and retained_faults | changed_faults == set(faults)

def score(text, ids):
    rows = [allbyid[i] for i in ids]
    opportunities = [f for f in faults if any((not matches(runs[f, r['id']], expected(r['new_expected'])) for r in rows))]
    result = {'assigned': True, 'edit_parse_ok': False, 'after_correct_pass': False, 'retained_obligations': sum((r['obligation'] == 'retained' for r in rows)), 'retained_exact_assertions_kept': 0, 'detected_faults': [], 'fault_fraction': 0.0, 'kept': 0}
    result.update(eligible_faults=opportunities, eligible_retained_faults=[f for f in opportunities if f in retained_faults], eligible_changed_contract_faults=[f for f in opportunities if f in changed_faults], detected_retained_faults=[], detected_changed_contract_faults=[], retained_fault_fraction=0.0 if any((f in retained_faults for f in opportunities)) else None, changed_contract_fault_fraction=0.0 if any((f in changed_faults for f in opportunities)) else None)
    try:
        drop, replace = parse(text, set(ids))
    except (ValueError, TypeError, SyntaxError, AssertionError, RecursionError, MemoryError) as e:
        result['parse_error'] = type(e).__name__ + ': ' + str(e)
        return result
    result['edit_parse_ok'] = True
    tests = [(r, replace.get(r['id'], expected(r['old_expected']))) for r in rows if r['id'] not in drop]
    result['kept'] = len(tests)
    result['after_correct_pass'] = all((matches(runs['after_correct', r['id']], e) for r, e in tests))
    result['retained_exact_assertions_kept'] = sum((r['obligation'] == 'retained' and equal(e, expected(r['new_expected'])) for r, e in tests))
    opportunities = [f for f in faults if any((not matches(runs[f, r['id']], expected(r['new_expected'])) for r in rows))]
    result['eligible_faults'] = opportunities
    if result['after_correct_pass']:
        result['detected_faults'] = [f for f in opportunities if any((not matches(runs[f, r['id']], e) for r, e in tests))]
    result['fault_fraction'] = len(result['detected_faults']) / len(opportunities) if opportunities else None
    result['retained_assertion_fraction'] = result['retained_exact_assertions_kept'] / result['retained_obligations'] if result['retained_obligations'] else None
    result['detected_retained_faults'] = [f for f in result['detected_faults'] if f in retained_faults]
    result['detected_changed_contract_faults'] = [f for f in result['detected_faults'] if f in changed_faults]
    result['retained_fault_fraction'] = len(result['detected_retained_faults']) / len(result['eligible_retained_faults']) if result['eligible_retained_faults'] else None
    result['changed_contract_fault_fraction'] = len(result['detected_changed_contract_faults']) / len(result['eligible_changed_contract_faults']) if result['eligible_changed_contract_faults'] else None
    return result
